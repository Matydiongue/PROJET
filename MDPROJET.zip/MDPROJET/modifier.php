<?php
include "projet.php";
$req = mysqli_query($link," UPDATE `lprojet` SET `id`='[value-1]',`code`='[value-2]',`nom`='[value-3]',`description`='[value-4]',`budget`='[value-5]',`date_debut`='[value-6]',`date_fin`='[value-7]',`statut`='[value-8]' WHERE 1 ");
?>