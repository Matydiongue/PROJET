<!Doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Affichage des Donnees</title>
        <style>
            body{
                width:30%;
                margin :auto;
            }
            table{
                border-collapse :collapse;
                margin : 25px;
                padding: 5px;
                font-size : 0.9em;
                font-family : sans-serif;
                box-shadow : 0 0 20px rgba(0,0,0,0.15);
            }
            td,th{
                padding : 10px;
                text-align : center;
            }
            thead{
                padding:30px;

            }
            tbody tr{
                border-bottom :1px solid #dddddd;
            }
            thead tr, tfoot tr{
                background-color : #009879;
                color : #ffffff;
                text-align : center;
            }
            tbody tr.active-row{
                font-weight : bold;
                color : #009879;

            }
            tbody tr:nth-of-type(even){
                background-color : #f3f3f3;
            }
            input[type="submit"]{
                background-color :#4caf50;
                border : none;
                border-radius: 3px;
                color : white;
                padding : 6px;
                text-align : center;
                font-weight : bold;
                margin : 5px;
            }
        </style>
    </head>
    <body>
        <h1>Affichage des Donnees</h1>
        <table>
            <thead>
            <tr>
                <th>Id</th>
                <th>Code</th>
                <th>Nom</th>
                <th>Description</th>
                <th>Budget</th>
                <th>Date_Debut</th>
                <th>Date_Fin</th>
                <th>Statut</th>
                <th>Action1</th>
                <th>Action2</th>
            </tr>
            </thead>
            <?php
                include "projet.php";
                $req = mysqli_query($link," SELECT * FROM lprojet ");
                while($res = mysqli_fetch_array($req)){
            ?>
            <tbody>
            <tr>
                <td><?php echo $res["id"];?></td>
                <td><?php echo $res["code"];?></td>
                <td><?php echo $res["nom"];?></td>
                <td><?php echo $res["description"];?></td>
                <td><?php echo $res["budget"];?></td>
                <td><?php echo $res["date_debut"];?></td>
                <td><?php echo $res["date_fin"];?></td>
                <td><?php echo $res["statut"];?></td>

                <td>
                    <form action="supprimer.php" method="post">
                        <input type="hidden" value="<?php echo $res["id"]; ?>">
                        <input type="submit" value="SUPPRIMER" >
                    </form>
                </td>
                <td>
                    <form action="modifier.php" method="post">
                        <input type="hidden" value="<?php echo $res["id"]; ?>">
                        <input type="submit" value="MODIFIER" >
                    </form>
                </td>
            </tr>
            </tbody>
            <?php
                }
            ?>
            <tfoot>
                <tr>
                    <td colspan=10>
                        Liste des Donnees Saisit
                    </td>
                </tr>
            </tfoot>
        </table>
    </body>
</html>