<?php
include "projet.php";
$req = mysqli_query($link, "DELETE FROM `lprojet` WHERE 1");
?>
