<?php
$user = "root";
$mdp = "";
$bd = "mdprojet";
$server = "localhost";

$link = mysqli_connect($server,$user,$mdp,$bd);
if($link){
   // echo "connexion reussit";
}

?>