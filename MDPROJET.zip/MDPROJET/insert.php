<?php
include "projet.php";
if(isset($_GET['id']) &&  isset($_GET['code']) && isset($_GET['nom']) && isset($_GET['description']) && isset($_GET['budget']) && isset($_GET['dated']) && isset($_GET['datef']) && isset($_GET['statut']))
{
    $id = $_GET['id'];
    $code = $_GET['code'];
    $nom = $_GET['nom'];
    $description = $_GET['description'];
    $budget = $_GET['budget'];
    $dated = $_GET['dated'];
    $datef = $_GET['datef'];
    $statut = $_GET['statut'];

    $req = mysqli_query($link, "insert into lprojet(code,nom,description,budget,date_debut,date_fin,statut) values ('$code','$nom','$description','$budget','$dated','$datef','$statut')");
    if($req){
        echo "Insertion Reuissit";
    }else{
        echo "Echec de la Connexion";
    }
}
?>